<?php

    class Revistasmodel extends Documentosmodel{
        
    }

?>