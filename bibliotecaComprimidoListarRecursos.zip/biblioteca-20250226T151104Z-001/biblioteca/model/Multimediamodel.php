<?php

    class Multimediamodel extends Documentosmodel{
        
        

    }

?>