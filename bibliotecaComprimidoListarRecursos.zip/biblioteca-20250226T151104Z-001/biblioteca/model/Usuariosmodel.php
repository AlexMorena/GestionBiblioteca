<?php
require_once(__DIR__ . "/Query.php");
require_once("../controller/sesiones.php");

class Usuariosmodel extends Query
{

    public function __construct()
    {
        parent::__construct();
    }

    public function iniciarSesionModel($email, $password)
    {
        $consulta = "SELECT * FROM Usuarios WHERE Email LIKE :email";
        $consultaAdmin = "SELECT * FROM Administradores WHERE email LIKE :email";
        try {
            $stmt = $this->con->prepare($consulta);
            $stmt->bindParam(":email", $email);
            $stmt->execute();
            $fila = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($fila['Contrasena'] == $password) {
                crearSesion($email,$password, $fila['Nombre']);
                return true;
            } else {
                $stmtAdmin = $this->con->prepare($consultaAdmin);
                $stmtAdmin->bindParam(":email", $email);
                $stmtAdmin->execute();
                $fila = $stmtAdmin->fetch(PDO::FETCH_ASSOC);
                if ($fila['contrasenia'] == $password) {
                    crearSesionAdmin($email,$password, $fila['Nombre']);
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}

?>