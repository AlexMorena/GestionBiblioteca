<?php
    class Query{
        
        public $con;
        
        public function __construct()
        {
            $pdo = "mysql:host=127.0.0.1;dbname=gestionBiblioteca;charset=utf8";
            $conex = new PDO($pdo, "root", "root");
            $conex->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->con = $conex;
        }
    }

?>