<?php
    require_once("Query.php");
    class Librosmodel extends Query{
        
        public function __construct()
        {
            parent::__construct();
        }

        function listarLibrosModel($ISBN){
            $query = "SELECT * FROM Libro INNER JOIN Documento ON Libro.idDocumento = Documento.idDocumeto where Libro.ISBN = :ISBN";
            $stmt = $this -> con -> prepare($query);
            $stmt -> bindParam(":ISBN",$ISBN);
            return $stmt;
        }
    }

?>