<?php
    require_once("../model/Librosmodel.php");

    class Libros{
        private $librosModel;
        public $isbn;
        private $datos = "";
        public function __construct($isbn)
        {
            $this->librosModel = new Librosmodel();
            $this->isbn = $isbn;
        }

        function listarLibros(){
            $stmt = $this -> librosModel -> listarLibrosModel($this->isbn);
            $stmt->execute();
            $this->datos .= "<table>";
            $this->datos .= "<tr>";
            $this->datos .= "<td>Titulo</td>";
            $this->datos .= "</tr>";
            while($fila = $stmt->fetch(PDO::FETCH_ASSOC)){
                $this->datos .= "<tr";
                $this->datos .= "<td>".$fila['Titulo']."</td>";
                $this->datos .= "</tr>";
            }
            $this->datos .= "</table>";
            return $this->datos;
        }

    }

?>
