<?php

    class Multimedia extends Documentos{
        
    }

?>
