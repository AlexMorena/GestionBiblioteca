<?php
require("../controller/sesiones.php");
if (isset($_POST['enviar'])) {
    require_once("../controller/Libros.php");
    $ISBN = $_POST['ISBN'];
    $prueba = new Libros($ISBN);
    /*$datos = $prueba->listarLibros(); */
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="./login.php">Volver al login</a></button>
    </div>
    <div id="cuerpo">
    <form action="?" method="post">
        ISBN:<input type="text" name="ISBN">
        <br><br>
        <input type="submit" name="enviar" value="Enviar">
    </form>
    <?php
    echo $prueba->isbn;
        if(isset($datos)){
            echo $datos;
        }
    ?>
    </div>
</body>

</html>