<?php

    class Librosmodel extends Documentosmodel{
        
    }

?>