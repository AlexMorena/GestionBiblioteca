<?php
require_once("../controller/sesiones.php");
if ($_GET['cerrarSesion'] === 'si') {
    cerrarSesion();
    header("Location: ../view/login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <br>
    <div id="cuerpo">
        <?php
        echo "<h1>Bievenido de nuevo, " . $_SESSION['nombre'] . "</h1>";
        if(isset($_SESSION['email'])){
            //Revista se lista por 
            echo "<button href=' '>Listar Revistas</button>";
            //Libro se lista por ISBN
            echo "<button href=' '>Listar Libros</button>";
            echo "<button href=' '>Listar Multimedia</button>";

        }else if(isset($_SESSION['admin'])){
            //funciones admin
        }else{
            //intentar llegar por URL
            header("Location: ./login.php?sinIniciarSesion=no");
        }
        ?>

    </div>
</body>

</html>