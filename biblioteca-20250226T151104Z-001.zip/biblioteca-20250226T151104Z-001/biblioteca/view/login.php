<?php
require_once(__DIR__ . "/../controller/Usuarios_controller.php");

if (isset($_POST['enviar'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $prueba = new UsuariosController();
    $prueba->iniciarSesion($email, $password);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
    </div>
    <br>
    <div id="cuerpo">
        <form action="?" method="POST">
            Email:<input type="text" name="email">
            <br><br>
            Password: <input type="text" name="password">
            <br>
            <input type="submit" name="enviar" value="Iniciar Sesion">
            <?php
            if ($_GET['logeado'] === 'no') {
                echo "<p style='color: red'>Credenciales incorrectos</p>";
            }
            if ($_GET['sinIniciarSesion'] === 'no') {
                echo "<p style='color: red'>Debes de iniciar sesion primero</p>";
            }
            ?>
        </form>
    </div>
</body>

</html>