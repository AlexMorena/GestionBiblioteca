<?php
require_once(__DIR__ . "/../model/Usuariosmodel.php");
class UsuariosController
{

    public $usuariomodel;
    public $datos;
    public function __construct()
    {
        $this->usuariomodel = new Usuariosmodel();
    }
    function iniciarSesion($email, $contraseña)
    {
        if ($this->usuariomodel->iniciarSesionModel($email, $contraseña)) {
            
            header("Location: ../view/menu.php");
        } else {
            header("Location: ../view/login.php?logeado=no");
        }
    }
}

?>