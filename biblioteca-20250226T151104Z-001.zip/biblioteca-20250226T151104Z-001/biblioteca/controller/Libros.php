<?php

    class Libros extends Documentos{
        
    }

?>
