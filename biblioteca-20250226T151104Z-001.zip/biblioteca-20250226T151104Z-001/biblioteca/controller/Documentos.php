<?php

    class Documentos extends Controller{
        
    }

?>
