<?php
/* ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); */
require_once("Query.php");
class Librosmodel extends Query
{

    public function __construct()
    {
        parent::__construct();
    }

    function listarLibrosNoPrestados()
    {
        $stmt = $this->con->prepare("SELECT DISTINCT Documento.Titulo, Ejemplar.idDocumento from Documento INNER JOIN Ejemplar ON
        Ejemplar.idDocumento = Documento.idDocumento INNER JOIN Libro ON
        Libro.idDocumento = Documento.idDocumento where Ejemplar.Prestado = 0");
        $stmt->execute();
        return $stmt;
    }

    function listarEjemplaresNoPrestados($id)
    {
        $stmt = $this->con->prepare("select * from Ejemplar INNER JOIN Documento ON
        Ejemplar.idDocumento = Documento.idDocumento INNER JOIN Libro ON
        Libro.idDocumento = Documento.idDocumento where Ejemplar.Prestado = 0 and Documento.idDocumento like ?");
        $stmt -> bindParam(1,$id);
        $stmt->execute();
        return $stmt;
    }

}

?>