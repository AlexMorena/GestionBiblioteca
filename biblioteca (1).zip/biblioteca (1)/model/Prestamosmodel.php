<?php

class Prestamosmodel extends Query
{

    public function __construct()
    {
        parent::__construct();

    }


    function prestarLibros($id)
    {
        $stmt = $this->con->prepare("update Ejemplar set prestado = 1 where idEjemplar = ?");
        $stmt->bindParam(1, $id);
        $stmt->execute();
    }

    function obtenerIdUsuario($email){
        $stmt = $this -> con -> prepare("select idUsuario from Usuarios where Email = ?");
        $stmt -> bindParam(1,$email);
        $stmt -> execute();
        $numero = $stmt -> fetch(PDO::FETCH_NUM);
        return $numero[0];
    }

    function consultarPrestamos($email){
        $stmt = $this -> con -> prepare("select count(*) from Prestar INNER JOIN Usuarios ON
        Usuarios.IdUsuario = Prestar.IdUsuario 
        where Usuarios.email like ? and CURRENT_DATE BETWEEN Prestar.FechaP and Prestar.FechaD");
        $stmt -> bindParam(1, $email);
        $stmt -> execute();
        $numero = $stmt -> fetch(PDO::FETCH_NUM);
        return $numero[0];

    }

    function insertarPrestamo($email, $idEjemplar){
        $fechaActual = new DateTime() ;
        $fechaActualString = $fechaActual->format('Y-m-d');
        $fechaEntregado = new DateTime();
        $fechaEntregado -> modify('+21 days');
        $fechaEntregadoString = $fechaEntregado ->format('Y-m-d');
        $id = $this -> obtenerIdUsuario($email);
        $stmt = $this -> con -> prepare("insert into Prestar(IdUsuario, IdEjemplar, FechaP, FechaD) values(?,?,?,?)");
        $stmt -> bindParam(1,$id);
        $stmt -> bindParam(2,$idEjemplar);
        $stmt -> bindParam(3,$fechaActualString);
        $stmt -> bindParam(4,$fechaEntregadoString);
        $stmt -> execute();

    }
}

?>