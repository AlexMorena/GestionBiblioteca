<?php
require_once("../model/Query.php");

class Documentosmodel extends Query
{
    public function __construct()
    {
        parent::__construct();
    }

    function listarPorValor($valor, $valor2)
    {
        try {
            if ($valor === "titulo") {
                $query = "SELECT * FROM Documento where Titulo like ?";
                $stmt = $this->con->prepare($query);
                $stmt->bindParam(1, $valor2, PDO::PARAM_STR);
                $stmt->execute();

                if ($stmt->rowCount() === 0) {  // 🔴 Si no hay resultados, muestra un mensaje
                    return null;
                }

                return $stmt;
            } else if ($valor === "autor") {
                $query = "SELECT * FROM Documento where ListaAutores like ?";
                $stmt = $this->con->prepare($query);
                $stmt->bindParam(1, $valor2, PDO::PARAM_STR);
                $stmt->execute();

                if ($stmt->rowCount() === 0) {  // 🔴 Si no hay resultados, muestra un mensaje
                    return null;
                }

                return $stmt;
            }


        } catch (Exception $e) {
            die("Error en consulta SQL: " . $e->getMessage()); // 🔴 Muestra el error SQL
        }
    }
    function listar_isbn_model($isbn)
    {
        $query = "SELECT * 
        FROM Documento 
        LEFT JOIN Libro 
            ON Documento.idDocumento = Libro.idDocumento 
        LEFT JOIN Revista 
            ON Documento.idDocumento = Revista.idDocumento 
        WHERE Revista.ISBN LIKE :isbn OR Libro.ISBN LIKE :isbn1";
        $stmt = $this->con->prepare($query);
        $stmt->bindParam(":isbn", $isbn);
        $stmt->bindParam(":isbn1", $isbn);
        $stmt->execute();
        return $stmt;
    }
}

?>