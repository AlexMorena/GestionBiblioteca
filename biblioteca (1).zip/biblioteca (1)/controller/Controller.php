<?php

    require_once("./biblioteca/model/Query.php");

    class Controller{
        
    }       

?>
