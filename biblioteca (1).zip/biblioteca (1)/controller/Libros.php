<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once("../model/Librosmodel.php");

class Libros
{
    private $librosModel;
    public $isbn;
    private $datos = "";
    public function __construct($isbn)
    {
        $this->librosModel = new Librosmodel();
        $this->isbn = $isbn;
    }

    function listarLibros(){
        try {
            $stmt = $this->librosModel->listarLibrosModel($this->isbn);
            //$stmt->execute();
            $this->datos .= "<table>";    
            while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->datos .= "<tr>";
                $this->datos .= "<th>Titulo</th><th>Autores</th><th>Editorial</th><th>Descripcion</th><th>ISBN</th><th>Numero Paginas</th>";

                $this->datos .= "</tr>";
                $this->datos .= "<tr>";
                $this->datos .= "<td>" . $fila['Titulo'] . "</td>";
                $this->datos .= "<td>" . $fila['ListaAutores'] . "</td>";
                $this->datos .= "<td>" . $fila['Editorial'] . "</td>";
                $this->datos .= "<td>" . $fila['Descripcion'] . "</td>";
                $this->datos .= "<td>" . $fila['ISBN'] . "</td>";
                $this->datos .= "<td>" . $fila['numPaginas'] . "</td>";
                $this->datos .= "</tr>";
            }
    
            $this->datos .= "</table>";
            return $this->datos;
    
        } catch (Exception $e) {
            return "Error: " . $e->getMessage();  // 🔴 Muestra el error en pantalla
        }
    }
    


}

?>