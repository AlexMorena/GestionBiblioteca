<?php
/* ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); */
require_once("../model/Multimediamodel.php");

    class Multimedia{
        
        private $multimediaModel;
        private $datos = "";

        public function __construct()
        {
            $this->multimediaModel = new Multimediamodel();
        }



        function listarMultimediaNoPrestadosController()
        {
            try {
                $stmt = $this->multimediaModel->listarMultimediaNoPrestadas();
                $this->datos .= "<table>";
                $this->datos .= "<tr>";
                $this->datos .= "<th>Titulo</th><th>Eleccion</th>";
                $this->datos .= "</tr>";
                while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $this->datos .= "<tr>";
                    $this->datos .= "<td>" . $fila['Titulo'] . "</td>";
                    $this->datos .= "<td><button><a href='../view/verEjemplarMultimedia.php?id=" . $fila['idDocumento'] . "'>Ver ejemplar</a></button></td>";
                    $this->datos .= "<br><br>";
                    $this->datos .= "</tr>";
                }
    
                $this->datos .= "</table>";
                return $this->datos;
    
            } catch (Exception $e) {
                return "Error: " . $e->getMessage();  // 🔴 Muestra el error en pantalla
            }
        }


        function listarEjemplaresNoPrestadosController($id)
        {
            try {
                $stmt = $this->multimediaModel->listarEjemplaresNoPrestados($id);
                $this->datos .= "<form action='?' method='post'>";
                $this->datos .= "<table>";
                $this->datos .= "<tr>";
                $this->datos .= "<th>Titulo</th><th>Localizacion</th><th>Coger Prestado</th>";
                $this->datos .= "</tr>";
                while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $this->datos .= "<tr>";
                    $this->datos .= "<td>" . $fila['Titulo'] . "</td>";
                    $this->datos .= "<td>" . $fila['Localizacion'] . "</td>";
                    $this->datos .= "<td><input type='radio' name='ejemplar' value='" . $fila["IdEjemplar"] . "'></td>";
                    $this->datos .= "<br><br>";
                    $this->datos .= "</tr>";
                }
    
                $this->datos .= "</table>";
                $this->datos .= "<br><br>";
                $this->datos .= "<input type='submit' name='Prestar' value='Prestar'>";
                $this->datos .= "</form>";
                return $this->datos;
    
            } catch (Exception $e) {
                return "Error: " . $e->getMessage();  // 🔴 Muestra el error en pantalla
            }
        }
    }
    

?>
