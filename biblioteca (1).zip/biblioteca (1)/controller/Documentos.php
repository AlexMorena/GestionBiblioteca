<?php
require_once("../model/Documentosmodel.php");


class Documentos
{

    private $documentoModel;

    private $datos;

    public function __construct()
    {
        $this->documentoModel = new Documentosmodel();
        $this->datos = "";
    }

    /* function listarDocumentosISBN()
    {
        try {
            $stmt = $this->documentoModel->listarPorValor("ISBN");
            //$stmt->execute();
            $this->datos .= "<table>";
            while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->datos .= "<tr>";
                $this->datos .= "<th>ISBN</th><th>numPaginas</th>";
                $this->datos .= "</tr>";
                $this->datos .= "<tr>";
                $this->datos .= "<td>" . $fila['ISBN'] . "</td>";
                $this->datos .= "<td>" . $fila['numPaginas'] . "</td>";
                $this->datos .= "</tr>";
            }
            $this->datos .= "</table>";
            return $this->datos;
        } catch (Exception $e) {
            return "Error: " . $e->getMessage();  // 🔴 Muestra el error en pantalla
        }
    } */
    function listar_isbn($isbn)
    {
        $stmt = $this->documentoModel->listar_isbn_model($isbn);
        $this->datos .= "<table>";
        $this->datos .= "<tr>";
        $this->datos .= "<th>ISBN</th><th>Titulo</th><th>Autor</th><th>Editorial</th>";
        $this->datos .= "</tr>";
        while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->datos .= "<tr>";
            $this->datos .= "<td>" . $fila['ISBN'] . "</td>";
            $this->datos .= "<td>" . $fila['Titulo'] . "</td>";
            $this->datos .= "<td>" . $fila['ListaAutores'] . "</td>";
            $this->datos .= "<td>" . $fila['Editorial'] . "</td>";
            $this->datos .= "</tr>";
        }
        return $this->datos;
    }
}

?>