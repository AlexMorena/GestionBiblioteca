<?php
require_once("../model/Documentosmodel.php");


class Documentos
{

    private $documentoModel;

    private $datos;

    public function __construct()
    {
        $this->documentoModel = new Documentosmodel();
        $this->datos = "";
    }

    function listarPorValor($valor, $valor2)
    {
                $stmt = $this->documentoModel->listarPorValor($valor,$valor2);
        $this->datos .= "<table>";
        $this->datos .= "<tr>";
        $this->datos .= "<th>Titulo</th><th>Autor</th><th>Editorial</th><th>Descripcion</th>";
        $this->datos .= "</tr>";
        while ($fila = $stmt->fetch(PDO::FETCH_NUM)) {
            $this->datos .= "<tr>";
            $this->datos .= "<td>" . $fila[1] . "</td>";
            $this->datos .= "<td>" . $fila[2] . "</td>";
            $this->datos .= "<td>" . $fila[4] . "</td>";
            $this->datos .= "<td>" . $fila[6] . "</td>";
            $this->datos .= "</tr>";
        }
        return $this->datos;
    }

    function listar_isbn($isbn)
    {
        $stmt = $this->documentoModel->listar_isbn_model($isbn);
        $this->datos .= "<table>";
        $this->datos .= "<tr>";
        $this->datos .= "<th>ISBN</th><th>Titulo</th><th>Autor</th><th>Editorial</th>";
        $this->datos .= "</tr>";
        while ($fila = $stmt->fetch(PDO::FETCH_NUM)) {
            $this->datos .= "<tr>";
            if(!empty($fila[9])){
                $this->datos .= "<td>" . $fila[9] . "</td>";

            }
            if(!empty($fila[12])){
                $this->datos .= "<td>" . $fila[12] . "</td>";
            }
            $this->datos .= "<td>" . $fila[1] . "</td>";
            $this->datos .= "<td>" . $fila[2] . "</td>";
            $this->datos .= "<td>" . $fila[4] . "</td>";
            $this->datos .= "</tr>";
        }
        return $this->datos;
    }
}

?>