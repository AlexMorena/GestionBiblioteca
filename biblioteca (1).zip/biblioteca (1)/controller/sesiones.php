<?php
    session_start();
    function crearSesion($email, $password, $nombre){
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
        $_SESSION['nombre'] = $nombre;
    }

    function crearSesionAdmin($email, $password, $nombre){
        $_SESSION['admin'] = $email;
        $_SESSION['passAdmin'] = $password;
        $_SESSION['nombre'] = $nombre;
    }    
    
    function cerrarSesion(){
        if(!empty($_SESSION['email'])) unset($_SESSION['email']); 
        if(!empty($_SESSION['password'])) unset($_SESSION['password']); 
        if(!empty($_SESSION['admin'])) unset($_SESSION['admin']); 
        if(!empty($_SESSION['passAdmin'])) unset($_SESSION['passAdmin']); 
        setcookie(session_name(),"",time()-3600);
        session_destroy();
    }
?>