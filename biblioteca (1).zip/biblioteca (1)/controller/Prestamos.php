<?php

    class Prestamos extends Controller{
        
    }

?>
