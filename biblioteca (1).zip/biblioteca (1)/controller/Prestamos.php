<?php
require_once("../model/Librosmodel.php");
require_once("../model/Prestamosmodel.php");
require_once("../controller/sesiones.php");



class Prestamos
{


    public function __construct()
    {
    }

    public function prestarLibro($id){
        $prestamo = new Prestamosmodel();
        $numero = $prestamo -> consultarPrestamos($_SESSION['email']);
        if($numero > 6){
            header("Location: ../view/menu.php?prestamos=maximos");
        }else{
            $prestamo -> insertarPrestamo($_SESSION['email'], $id);
            $prestamo -> prestarLibros($id);
            echo "<p style='color: green'>Se ha prestado correctamente</p>";
        }
    }


}

?>