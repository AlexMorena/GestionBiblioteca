<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once(__DIR__ . "/../model/Usuariosmodel.php");
require_once(__DIR__ . "/../controller/sesiones.php");

class UsuariosController

{

    public $usuariomodel;
    public $datos;
    public function __construct()
    {
        $this->usuariomodel = new Usuariosmodel();
    }
    function iniciarSesion($email, $contraseña)
    {
        if ($this->usuariomodel->iniciarSesionModel($email, $contraseña)) {
        $_SESSION['email'] = $email;
            header("Location: ../view/menu.php");
        } else {
            header("Location: ../view/login.php?logeado=no");
        }
    }
}

?>