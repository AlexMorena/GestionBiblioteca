<?php
require_once("../controller/sesiones.php");

if (!isset($_SESSION['email'])) {
    header("Location: login.php?sin=logearse");
}
/* ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); */
require_once("../controller/Revistas.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $prueba = new Revistas();
    $datos = $prueba->listarEjemplaresNoPrestadosController($id);
}

if(isset($_POST['Prestar'])){
    $idEjemplar = $_POST['ejemplar'];
    require_once("../controller/Prestamos.php");
    $prestamos = new Prestamos();
    $prestamos -> prestarLibro($idEjemplar);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>listar Documentos</title>
    <link rel="stylesheet" href="./estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <div id="cuerpo">
        <?php
        echo "<br><br>";
        if (isset($datos)) {
            echo $datos;
        }
        if(isset($_POST['Prestar'])){
            echo "<p style='color: green'>Se ha prestado correctamente</p>";

        }
        echo "<button><a href='menu.php'>Volver</a></button>";

        ?>
    </div>
</body>

</html>