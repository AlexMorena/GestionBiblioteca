<?php
require_once("../controller/sesiones.php");
if ($_GET['cerrarSesion'] === 'si') {
    cerrarSesion();
    header("Location: ../view/login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <br>
    <div id="cuerpo">
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);        
        echo "<h1>Bievenido de nuevo, " . $_SESSION['nombre'] . "</h1>";
        if (isset($_SESSION['email'])) {
            echo "<button><a href='eleccion.php'>Listar Documentos</a></button>";
            echo "<br><br>";
            echo "<button><a href='eleccionPrestar.php'>Prestar Documento</a></button>";
            echo "<br><br>";
            if($_GET['prestamos'] === "maximos"){
                echo "<p style='color: red'>Tienes el maximo de prestamos activos</p>";
            }
        } else if (isset($_SESSION['admin'])) {
            //funciones admin
        } else {
            //intentar llegar por URL
            header("Location: ./login.php?sinIniciarSesion=no");
        }
        ?>

    </div>
</body>

</html>