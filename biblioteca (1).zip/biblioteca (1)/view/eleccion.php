<?php
require_once("../controller/sesiones.php");
if ($_GET['cerrarSesion'] === 'si') {
    cerrarSesion();
    header("Location: ../view/login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eleccion de listado</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <br>
    <div id="cuerpo">
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);        
        if (isset($_SESSION['email'])) {
            echo "<h3>Por que desea listar</h3>";
            echo "<form action='introducirValor.php' method='post'>";
            echo "<select name='listado'>";
            echo "<option value='autor'>Autor</option>";
            echo "<option value='ISBN'>ISBN</option>";
            echo "<option value='titulo'>Titulo</option>";
            echo "</select>";
            echo "<br><br>";
            echo "<input type='submit' name='Enviar' value='Enviar'>";
            echo "<br><br>";
            echo "<button><a href='menu.php'>Volver atras</a></button>";
            echo "<br><br>";
            echo "</form>";
        } else {
            //intentar llegar por URL
            header("Location: ./login.php?sinIniciarSesion=no");
        }
        ?>

    </div>
</body>

</html>