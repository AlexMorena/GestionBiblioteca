<?php
if (!isset($_SESSION['email'])) {
    header("Location: login.php?sin=logearse");
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require("../controller/sesiones.php");
if (isset($_POST['Enviar'])) {
    require_once("../controller/Documentos.php");
    $autor = $_POST['autor'];
    $tipo = $_POST['tipo'];
    $prueba = new Documentos();
    $datos = $prueba->listarPorValor($tipo, $autor);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>listar Documentos</title>
    <link rel="stylesheet" href="./estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <div id="cuerpo">
        <form action="?" method="post">
            Autor:<input type="text" name="autor">
            <br><br>
            <input type="submit" name="Enviar" value="Enviar">
            <?php echo "<input type='hidden' name='tipo' value='$tipo'>";
            ?>
        </form>
        <?php
        echo "<br><br>";
        if (isset($datos)) {
            echo $datos;
        }
        echo "<button><a href='menu.php'>Volver</a></button>";
        ?>
    </div>
</body>

</html>