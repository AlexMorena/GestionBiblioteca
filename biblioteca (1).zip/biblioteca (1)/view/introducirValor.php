<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>listar Documentos</title>
    <link rel="stylesheet" href="./estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <div id="cuerpo">
        <?php
        $listado = $_POST['listado'];
        if ($listado == "ISBN") {
            echo '<form action="listarISBN.php" method="post">';
            echo 'ISBN: <input type="text" name="ISBN">';
            echo '<br><br>';
            echo "<input type='hidden' name='tipo' value='$listado'>";
            echo '<input type="submit" name="Enviar" value="Enviar">';
            echo '</form>';
        } else if ($listado == "titulo") {
            echo '<form action="listarTitulo.php" method="post">';
            echo 'Titulo: <input type="text" name="titulo">';
            echo '<br><br>';
            echo "<input type='hidden' name='tipo' value='$listado'>";
            echo '<input type="submit" name="Enviar" value="Enviar">';
            echo '</form>';
        } else {
            echo '<form action="listarAutor.php" method="post">';
            echo 'Autor: <input type="text" name="autor">';
            echo '<br><br>';
            echo "<input type='hidden' name='tipo' value='$listado'>";
            echo '<input type="submit" name="Enviar" value="Enviar">';
            echo '</form>';
        }
        ?>
    </div>
</body>

</html>