<?php
require_once("../controller/sesiones.php");
require_once("../controller/Libros.php");
require_once("../controller/Revistas.php");
require_once("../controller/Multimedia.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eleccion de listado</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>
    <div id="cabecera">
        <h1>Gestiona Biblioteca</h1>
        <button><a href="menu.php?cerrarSesion=si">Cerrar Sesión</a></button>
    </div>
    <br>
    <div id="cuerpo">
        <?php
/*         ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL); */
        $boton = $_POST['Enviar'];
        if (isset($_SESSION['email'])) {
            if ($boton != "Enviar") {
                echo "<h3>Que desea obtener prestado</h3>";
                echo "<form action='?' method='post'>";
                echo "<select name='prestado'>";
                echo "<option value='libros'>Libros</option>";
                echo "<option value='revistas'>Revistas</option>";
                echo "<option value='multimedia'>Multimedia</option>";
                echo "</select>";
                echo "<br><br>";
                echo "<input type='submit' name='Enviar' value='Enviar'>";
                echo "<br><br>";
                echo "<button><a href='menu.php'>Volver atras</a></button>";
                echo "<br><br>";
                echo "</form>";
            } else {
                if($_POST['prestado'] === "libros"){
                    $libro = new Libros();
                    echo $libro -> listarLibrosNoPrestadosController();
                }else if($_POST['prestado'] === "revistas"){
                    $revista = new Revistas();
                    echo $revista -> listarRevistasNoPrestadosController();
                }else{
                    $multimedia = new Multimedia();
                    echo $multimedia -> listarMultimediaNoPrestadosController();
                }
            }
        } else {
            //intentar llegar por URL
            header("Location: ./login.php?sinIniciarSesion=no");
        }
        ?>

    </div>
</body>

</html>