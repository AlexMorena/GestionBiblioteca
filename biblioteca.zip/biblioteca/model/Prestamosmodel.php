<?php

    class Prestamosmodel extends Query{
        
    }

?>