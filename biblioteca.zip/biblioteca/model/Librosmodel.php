<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once("Query.php");
class Librosmodel extends Query
{

    public function __construct()
    {
        parent::__construct();
    }

    function listarLibrosModel($ISBN){
        try {
            $query = "SELECT * FROM Libro INNER JOIN Documento ON Libro.idDocumento = Documento.idDocumento WHERE Libro.ISBN LIKE :ISBN";
            $stmt = $this->con->prepare($query);
            $stmt->bindParam(":ISBN", $ISBN, PDO::PARAM_STR);
            $stmt->execute();
    
           if ($stmt->rowCount() === 0) {  // 🔴 Si no hay resultados, muestra un mensaje
                return null;
            } 
            
            return $stmt;
    
        } catch (Exception $e) {
            die("Error en consulta SQL: " . $e->getMessage()); // 🔴 Muestra el error SQL
        }
    }
    
}

?>