<?php

    class Documentosmodel extends Query{
        
    }
    
?>