<?php

class Documentosmodel extends Query
{
    public function __construct()
    {
        parent::__construct();
    }

    function listarPorISBN(){
        echo "<h2>Por que desea filtrar el ISBN</h2>";
        echo "<select name='eleccion'>";
        echo "<option value='Libro'>Libro</option>";
        echo "</select>";
        echo "</form>";
    }

    function listarPorValor($valor)
    {
        try {
            if ($valor === "Titulo") {
                $query = "SELECT * FROM Documento where Titulo like ?";
                $stmt = $this->con->prepare($query);
                $stmt->bindParam(1, $valor, PDO::PARAM_STR);
                $stmt->execute();

                if ($stmt->rowCount() === 0) {  // 🔴 Si no hay resultados, muestra un mensaje
                    return null;
                }

                return $stmt;
            } else if ($valor === "Autor") {
                $query = "SELECT * FROM Documento where ListaAutores like ?";
                $stmt = $this->con->prepare($query);
                $stmt->bindParam(1, $valor, PDO::PARAM_STR);
                $stmt->execute();

                if ($stmt->rowCount() === 0) {  // 🔴 Si no hay resultados, muestra un mensaje
                    return null;
                }

                return $stmt;
            } else {
                $query = "SELECT * FROM Libro where ISBN like ?";
                $stmt = $this->con->prepare($query);
                $stmt->bindParam(1, $valor, PDO::PARAM_STR);
                $stmt->execute();

                if ($stmt->rowCount() === 0) {  // 🔴 Si no hay resultados, muestra un mensaje
                    return null;
                }
                return $stmt;
            }


        } catch (Exception $e) {
            die("Error en consulta SQL: " . $e->getMessage()); // 🔴 Muestra el error SQL
        }
    }
}

?>