<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class Query
{

    public $con;

    public function __construct()
    {
        try {
            $pdo = "mysql:host=127.0.0.1;dbname=gestionBiblioteca;charset=utf8";
            $conex = new PDO($pdo, "root", "root");
            $conex->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->con = $conex;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}

?>