<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once(__DIR__ . "/../controller/Usuarios_controller.php");
require_once("./login.php");
?>
