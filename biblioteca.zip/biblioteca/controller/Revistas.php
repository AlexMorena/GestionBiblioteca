<?php

try {
    $pdo = "mysql:host=127.0.0.1;dbname=gestionBiblioteca;charset=utf8";
    $conex = new PDO($pdo, "root", "root");
    $conex->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Conexión exitosa";

                $consulta = "SELECT * FROM Usuarios WHERE Email LIKE :email";
                $stmt = $conex-> prepare($consulta);
                $stmt -> bindParam(":email", $email);
                $stmt->execute();
                $fila = $stmt->fetch(PDO::FETCH_ASSOC);
                if($fila['Contrasena'] == $password){
                    echo "Login correcto";
                }        
                else{
                    echo "Login incorrecto";
                }
            } catch (Exception $e){
                echo $e->getMessage();
            }

?>
